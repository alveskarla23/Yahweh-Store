/* =========================================================
   CONFIGURACIÓN DE LA TIENDA — Yahweh Store
   Cambia SOLO lo que está entre comillas o los números.
   ========================================================= */
window.TIENDA = {
  nombre: "Yahweh Store",
  lema: "Showroom | Tienda Online",
  ciudad: "Ciudad Bolívar",
  pais: "Venezuela",
  envios: "Envíos nacionales",

  // WhatsApp: código de país + número, SIN +, espacios ni guiones. Ej: 584121234567
  whatsapp: "584148938240",
  // Usuario de Instagram y TikTok SIN @
  instagram: "yahweh_str",
  tiktok: "",   // déjalo vacío si no quieres mostrar TikTok

  // Tasa BCV del día (bolívares por 1 dólar). Actualízala cada mañana.
  tasaBCV: 922.56,
  fechaTasa: "25/11/2026",

  // Pago móvil que ven las clientas en el carrito
  pagoMovil: "Bancamiga · C.I. 28240537 · 04148938240",
  formasDePago: "Pago móvil, Dólares efectivo, Zinli, Transferencia",
  entregas: "Retiro en el showroom · Delivery (según zona) · Envío nacional por MRW o Zoom",

  // Guía de tallas (medidas en centímetros). Edita, agrega o quita filas.
  guiaTallas: [
    { talla: "S",  busto: "84-88",   cintura: "64-68", cadera: "90-94"   },
    { talla: "M",  busto: "88-92",   cintura: "68-72", cadera: "94-98"   },
    { talla: "L",  busto: "92-98",   cintura: "72-78", cadera: "98-104"  },
    { talla: "XL", busto: "98-104",  cintura: "78-84", cadera: "104-110" }
  ]
};
