/* Tus prendas reales (copiadas de tu web el 25/11/2026).
   Fotos en img/productos/. descuento: 15 = -15%. Para ocultar: disponible: false */
window.PRODUCTOS = [
  {
    "ref": "Bo40",
    "nombre": "Body de hombros · Crema",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "XL"
    ],
    "foto": "img/productos/001-bo40-crema.jpg",
    "fotos": [
      "img/productos/001-bo40-crema.jpg",
      "img/productos/001-bo40-crema-2.jpg"
    ],
    "descripcion": "Tela de algodón",
    "disponible": true
  },
  {
    "ref": "Bo39",
    "nombre": "Body tipo Zara · Azul cielo",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/002-bo39-azul-cielo.jpg",
    "fotos": [
      "img/productos/002-bo39-azul-cielo.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo38",
    "nombre": "Body asimétrico · Azul claro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/003-bo38-azul-claro.jpg",
    "fotos": [
      "img/productos/003-bo38-azul-claro.jpg",
      "img/productos/003-bo38-azul-claro-2.jpg"
    ],
    "descripcion": "Doble tela licrada (espalda descubierta)",
    "disponible": true
  },
  {
    "ref": "Bo37",
    "nombre": "Body tipo zara · Negro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/004-bo37-negro.jpg",
    "fotos": [
      "img/productos/004-bo37-negro.jpg"
    ],
    "descripcion": "Doble tela (no estira)",
    "disponible": true
  },
  {
    "ref": "Bo36",
    "nombre": "Body tipo zara · Azul oscuro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/005-bo36-azul-oscuro.jpg",
    "fotos": [
      "img/productos/005-bo36-azul-oscuro.jpg"
    ],
    "descripcion": "Doble tela licrada (gruesa)",
    "disponible": true
  },
  {
    "ref": "Bo35",
    "nombre": "Body asimétrico · Azul claro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/006-bo35-azul-claro.jpg",
    "fotos": [
      "img/productos/006-bo35-azul-claro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo34",
    "nombre": "Body · Vinotinto",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/007-bo34-vinotinto.jpg",
    "fotos": [
      "img/productos/007-bo34-vinotinto.jpg",
      "img/productos/007-bo34-vinotinto-2.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo33",
    "nombre": "Body tipo halter · Vino tinto",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/008-bo33-vino-tinto.jpg",
    "fotos": [
      "img/productos/008-bo33-vino-tinto.jpg",
      "img/productos/008-bo33-vino-tinto-2.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo32",
    "nombre": "Body de tiros · Verde agua",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/009-bo32-verde-agua.jpg",
    "fotos": [
      "img/productos/009-bo32-verde-agua.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo31",
    "nombre": "Body de tiros · Negro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/010-bo31-negro.jpg",
    "fotos": [
      "img/productos/010-bo31-negro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo30",
    "nombre": "Body · Verde esmeralda",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/011-bo30-verde-esmeralda.jpg",
    "fotos": [
      "img/productos/011-bo30-verde-esmeralda.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo29",
    "nombre": "Body · Azul oscuro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/012-bo29-azul-oscuro.jpg",
    "fotos": [
      "img/productos/012-bo29-azul-oscuro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo29",
    "nombre": "Body · Azul claro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/013-bo29-azul-claro.jpg",
    "fotos": [
      "img/productos/013-bo29-azul-claro.jpg"
    ],
    "descripcion": "Doble tela licrada (La tela es finita)",
    "disponible": true
  },
  {
    "ref": "Bo28",
    "nombre": "Body · Coral",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/014-bo28-coral.jpg",
    "fotos": [
      "img/productos/014-bo28-coral.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo27",
    "nombre": "Body · Naranja claro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/015-bo27-naranja-claro.jpg",
    "fotos": [
      "img/productos/015-bo27-naranja-claro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo26",
    "nombre": "Body · Verde agua",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/016-bo26-verde-agua.jpg",
    "fotos": [
      "img/productos/016-bo26-verde-agua.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo25",
    "nombre": "Body · Negro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/017-bo25-negro.jpg",
    "fotos": [
      "img/productos/017-bo25-negro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo24",
    "nombre": "Body · Gris",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/018-bo24-gris.jpg",
    "fotos": [
      "img/productos/018-bo24-gris.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo23",
    "nombre": "Body · Coral",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/019-bo23-coral.jpg",
    "fotos": [
      "img/productos/019-bo23-coral.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo22",
    "nombre": "Body elegante · Negro",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/020-bo22-negro.jpg",
    "fotos": [
      "img/productos/020-bo22-negro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo21",
    "nombre": "Body elegante · Blanco",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/021-bo21-blanco.jpg",
    "fotos": [
      "img/productos/021-bo21-blanco.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo20",
    "nombre": "Body elegante · Marrón",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/022-bo20-marron.jpg",
    "fotos": [
      "img/productos/022-bo20-marron.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo10",
    "nombre": "Body elegante · Azul marino",
    "categoria": "Bodys",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/023-bo10-azul-marino.jpg",
    "fotos": [
      "img/productos/023-bo10-azul-marino.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Acce12",
    "nombre": "Cartera mediana · Negra",
    "categoria": "Accesorios",
    "subcategoria": "",
    "precio": 40.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/024-acce12-negra.jpg",
    "fotos": [
      "img/productos/024-acce12-negra.jpg",
      "img/productos/024-acce12-negra-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu15",
    "nombre": "Blusa tipo chemise · Crema con rayas negra",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 22.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/025-blu15-crema-con-rayas-negra.jpg",
    "fotos": [
      "img/productos/025-blu15-crema-con-rayas-negra.jpg",
      "img/productos/025-blu15-crema-con-rayas-negra-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu14",
    "nombre": "Blusa tipo chemise · Crema con rayas negra",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 19.0,
    "descuento": 0,
    "tallas": [
      "XS",
      "S"
    ],
    "foto": "img/productos/026-blu14-crema-con-rayas-negra.jpg",
    "fotos": [
      "img/productos/026-blu14-crema-con-rayas-negra.jpg",
      "img/productos/026-blu14-crema-con-rayas-negra-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu13",
    "nombre": "Blusa · Marrón",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/027-blu13-marron.jpg",
    "fotos": [
      "img/productos/027-blu13-marron.jpg",
      "img/productos/027-blu13-marron-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu12",
    "nombre": "Blusa · Vinotinto",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/028-blu12-vinotinto.jpg",
    "fotos": [
      "img/productos/028-blu12-vinotinto.jpg",
      "img/productos/028-blu12-vinotinto-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu11",
    "nombre": "Blusa manga larga · Crema",
    "categoria": "Blusas",
    "subcategoria": "Manga larga",
    "precio": 28.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/029-blu11-crema.jpg",
    "fotos": [
      "img/productos/029-blu11-crema.jpg",
      "img/productos/029-blu11-crema-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu09",
    "nombre": "Blusa manga larga · Vinotinto",
    "categoria": "Blusas",
    "subcategoria": "Manga larga",
    "precio": 28.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/030-blu09-vinotinto.jpg",
    "fotos": [
      "img/productos/030-blu09-vinotinto.jpg",
      "img/productos/030-blu09-vinotinto-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Fal02",
    "nombre": "Falda de satin · Champán",
    "categoria": "Faldas",
    "subcategoria": "",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/031-fal02-champan.jpg",
    "fotos": [
      "img/productos/031-fal02-champan.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pan5",
    "nombre": "Pantalón de vestir · Blanco",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/032-pan5-blanco.jpg",
    "fotos": [
      "img/productos/032-pan5-blanco.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pan4",
    "nombre": "Pantalon de vestir · Azul claro",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/033-pan4-azul-claro.jpg",
    "fotos": [
      "img/productos/033-pan4-azul-claro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pan4",
    "nombre": "Pantalón de vestir · Beige",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M",
      "L"
    ],
    "foto": "img/productos/034-pan4-beige.jpg",
    "fotos": [
      "img/productos/034-pan4-beige.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pan3",
    "nombre": "Pantalones de vestir · Blanco",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 40.0,
    "descuento": 15,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/035-pan3-blanco.jpg",
    "fotos": [
      "img/productos/035-pan3-blanco.jpg"
    ],
    "descripcion": "Incluye la correa",
    "disponible": true
  },
  {
    "ref": "Pan3",
    "nombre": "Pantalón de vestir · Azul oscuro",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 40.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M",
      "L"
    ],
    "foto": "img/productos/036-pan3-azul-oscuro.jpg",
    "fotos": [
      "img/productos/036-pan3-azul-oscuro.jpg",
      "img/productos/036-pan3-azul-oscuro-2.jpg"
    ],
    "descripcion": "Incluye la correa",
    "disponible": true
  },
  {
    "ref": "Pan2",
    "nombre": "Pantalón de vestir · Marrón",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 40.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/037-pan2-marron.jpg",
    "fotos": [
      "img/productos/037-pan2-marron.jpg"
    ],
    "descripcion": "Incluye la correa",
    "disponible": true
  },
  {
    "ref": "Pa8",
    "nombre": "Pañoleta · Naranja",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/038-pa8-naranja.jpg",
    "fotos": [
      "img/productos/038-pa8-naranja.jpg",
      "img/productos/038-pa8-naranja-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa7",
    "nombre": "Pañoleta · Blanco y negro",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/039-pa7-blanco-y-negro.jpg",
    "fotos": [
      "img/productos/039-pa7-blanco-y-negro.jpg",
      "img/productos/039-pa7-blanco-y-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa6",
    "nombre": "Pañoleta · Blanco y negro",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/040-pa6-blanco-y-negro.jpg",
    "fotos": [
      "img/productos/040-pa6-blanco-y-negro.jpg",
      "img/productos/040-pa6-blanco-y-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa5",
    "nombre": "Pañoleta · Beig",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/041-pa5-beig.jpg",
    "fotos": [
      "img/productos/041-pa5-beig.jpg",
      "img/productos/041-pa5-beig-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa4",
    "nombre": "Pañoleta · Azul",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/042-pa4-azul.jpg",
    "fotos": [
      "img/productos/042-pa4-azul.jpg",
      "img/productos/042-pa4-azul-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa3",
    "nombre": "Pañoleta · Rosada",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/043-pa3-rosada.jpg",
    "fotos": [
      "img/productos/043-pa3-rosada.jpg",
      "img/productos/043-pa3-rosada-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa2",
    "nombre": "Pañoleta · Fucsia",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/044-pa2-fucsia.jpg",
    "fotos": [
      "img/productos/044-pa2-fucsia.jpg",
      "img/productos/044-pa2-fucsia-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pa1",
    "nombre": "Pañoleta · Rosada",
    "categoria": "Accesorios",
    "subcategoria": "Pañoletas",
    "precio": 8.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/045-pa1-rosada.jpg",
    "fotos": [
      "img/productos/045-pa1-rosada.jpg",
      "img/productos/045-pa1-rosada-2.jpg",
      "img/productos/045-pa1-rosada-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu07",
    "nombre": "Blusa tejida · Rosada",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/046-blu07-rosada.jpg",
    "fotos": [
      "img/productos/046-blu07-rosada.jpg",
      "img/productos/046-blu07-rosada-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Su2",
    "nombre": "Suéter dé rayas · Blanco y negro",
    "categoria": "Blusas",
    "subcategoria": "Manga larga",
    "precio": 44.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/047-su2-blanco-y-negro.jpg",
    "fotos": [
      "img/productos/047-su2-blanco-y-negro.jpg",
      "img/productos/047-su2-blanco-y-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Bas05",
    "nombre": "Top de suéter · Marrón",
    "categoria": "Básicos",
    "subcategoria": "Manga larga",
    "precio": 16.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/048-bas05-marron.jpg",
    "fotos": [
      "img/productos/048-bas05-marron.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Bas03",
    "nombre": "Top de suéter · Negro",
    "categoria": "Básicos",
    "subcategoria": "Manga larga",
    "precio": 16.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/049-bas03-negro.jpg",
    "fotos": [
      "img/productos/049-bas03-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc15",
    "nombre": "Correa · Camel",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/050-acc15-camel.jpg",
    "fotos": [
      "img/productos/050-acc15-camel.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc14",
    "nombre": "Correa ajustable · Marrón",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/051-acc14-marron.jpg",
    "fotos": [
      "img/productos/051-acc14-marron.jpg",
      "img/productos/051-acc14-marron-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc13",
    "nombre": "Correa · Camel",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/052-acc13-camel.jpg",
    "fotos": [
      "img/productos/052-acc13-camel.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc12",
    "nombre": "Correa · Marrón",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/053-acc12-marron.jpg",
    "fotos": [
      "img/productos/053-acc12-marron.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc11",
    "nombre": "Correa ajustable · Camel",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/054-acc11-camel.jpg",
    "fotos": [
      "img/productos/054-acc11-camel.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc10",
    "nombre": "Correa · Negra",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/055-acc10-negra.jpg",
    "fotos": [
      "img/productos/055-acc10-negra.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc09",
    "nombre": "Correa · Negra",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/056-acc09-negra.jpg",
    "fotos": [
      "img/productos/056-acc09-negra.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Acc07",
    "nombre": "Correa · Negro",
    "categoria": "Accesorios",
    "subcategoria": "Correas",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/057-acc07-negro.jpg",
    "fotos": [
      "img/productos/057-acc07-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top09",
    "nombre": "Top manga corta · Marrón",
    "categoria": "Básicos",
    "subcategoria": "Manga corta",
    "precio": 14.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/058-top09-marron.jpg",
    "fotos": [
      "img/productos/058-top09-marron.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top08",
    "nombre": "Crop top · crema",
    "categoria": "Básicos",
    "subcategoria": "Manga corta",
    "precio": 14.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/059-top08-crema.jpg",
    "fotos": [
      "img/productos/059-top08-crema.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top06",
    "nombre": "Crop top · Negro",
    "categoria": "Básicos",
    "subcategoria": "Manga corta",
    "precio": 14.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/060-top06-negro.jpg",
    "fotos": [
      "img/productos/060-top06-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top05",
    "nombre": "Top de sueter · Blanco",
    "categoria": "Básicos",
    "subcategoria": "Sueter",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS",
      "S"
    ],
    "foto": "img/productos/061-top05-blanco.jpg",
    "fotos": [
      "img/productos/061-top05-blanco.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top05",
    "nombre": "Top de suéter · Negro",
    "categoria": "Básicos",
    "subcategoria": "Sueter",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS",
      "S"
    ],
    "foto": "img/productos/062-top05-negro.jpg",
    "fotos": [
      "img/productos/062-top05-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top04",
    "nombre": "Top de sueter · Marrón",
    "categoria": "Básicos",
    "subcategoria": "Sueter",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS",
      "S"
    ],
    "foto": "img/productos/063-top04-marron.jpg",
    "fotos": [
      "img/productos/063-top04-marron.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pan03",
    "nombre": "Pantalón jeans · Jeans oscuro",
    "categoria": "Pantalones",
    "subcategoria": "Jeans",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M",
      "L"
    ],
    "foto": "img/productos/064-pan03-jeans-oscuro.jpg",
    "fotos": [
      "img/productos/064-pan03-jeans-oscuro.jpg",
      "img/productos/064-pan03-jeans-oscuro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top03",
    "nombre": "Top básicos · Amarillo",
    "categoria": "Básicos",
    "subcategoria": "",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/065-top03-amarillo.jpg",
    "fotos": [
      "img/productos/065-top03-amarillo.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top02",
    "nombre": "Top básico · Rayas vinotinto",
    "categoria": "Básicos",
    "subcategoria": "",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/066-top02-rayas-vinotinto.jpg",
    "fotos": [
      "img/productos/066-top02-rayas-vinotinto.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Top01",
    "nombre": "Top basico · Negro",
    "categoria": "Basicos",
    "subcategoria": "",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/067-top01-negro.jpg",
    "fotos": [
      "img/productos/067-top01-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Pull06",
    "nombre": "Pullover animal print · Animal print",
    "categoria": "Pullover",
    "subcategoria": "",
    "precio": 24.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/068-pull06-animal-print.jpg",
    "fotos": [
      "img/productos/068-pull06-animal-print.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ves10",
    "nombre": "Vestido blanco · Blanco",
    "categoria": "Vestidos",
    "subcategoria": "",
    "precio": 48.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/069-ves10-blanco.jpg",
    "fotos": [
      "img/productos/069-ves10-blanco.jpg",
      "img/productos/069-ves10-blanco-2.jpg",
      "img/productos/069-ves10-blanco-3.jpg"
    ],
    "descripcion": "Tela tejida",
    "disponible": true
  },
  {
    "ref": "Bo17",
    "nombre": "Body manga larga · Blanco",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "M",
      "L"
    ],
    "foto": "img/productos/070-bo17-blanco.jpg",
    "fotos": [
      "img/productos/070-bo17-blanco.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo16",
    "nombre": "Body manga larga · Rojo",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/071-bo16-rojo.jpg",
    "fotos": [
      "img/productos/071-bo16-rojo.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo14",
    "nombre": "Body manga larga · Negro",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/072-bo14-negro.jpg",
    "fotos": [
      "img/productos/072-bo14-negro.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo13",
    "nombre": "Body manga larga · Beige",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "M",
      "L"
    ],
    "foto": "img/productos/073-bo13-beige.jpg",
    "fotos": [
      "img/productos/073-bo13-beige.jpg",
      "img/productos/073-bo13-beige-2.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo13",
    "nombre": "Body manga larga · Negro satinado",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/074-bo13-negro-satinado.jpg",
    "fotos": [
      "img/productos/074-bo13-negro-satinado.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo11",
    "nombre": "Bodys manga larga · Azul satinado",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/075-bo11-azul-satinado.jpg",
    "fotos": [
      "img/productos/075-bo11-azul-satinado.jpg",
      "img/productos/075-bo11-azul-satinado-2.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo10",
    "nombre": "Bodys manga larga · Gris",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/076-bo10-gris.jpg",
    "fotos": [
      "img/productos/076-bo10-gris.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo09",
    "nombre": "Bodys manga larga · Azul turquesa",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/077-bo09-azul-turquesa.jpg",
    "fotos": [
      "img/productos/077-bo09-azul-turquesa.jpg",
      "img/productos/077-bo09-azul-turquesa-2.jpg"
    ],
    "descripcion": "Doble tela licrada",
    "disponible": true
  },
  {
    "ref": "Bo07",
    "nombre": "Bodys manga larga · Azul oscuro",
    "categoria": "Bodys",
    "subcategoria": "Bodys manga larga",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/078-bo07-azul-oscuro.jpg",
    "fotos": [
      "img/productos/078-bo07-azul-oscuro.jpg",
      "img/productos/078-bo07-azul-oscuro-2.jpg",
      "img/productos/078-bo07-azul-oscuro-3.jpg",
      "img/productos/078-bo07-azul-oscuro-4.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Pan02",
    "nombre": "Pantalón de vestir · Negro",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M",
      "L"
    ],
    "foto": "img/productos/079-pan02-negro.jpg",
    "fotos": [
      "img/productos/079-pan02-negro.jpg",
      "img/productos/079-pan02-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu10",
    "nombre": "Blusa · Beige con marrón",
    "categoria": "Blusas",
    "subcategoria": "polka dots",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/080-blu10-beige-con-marron.jpg",
    "fotos": [
      "img/productos/080-blu10-beige-con-marron.jpg",
      "img/productos/080-blu10-beige-con-marron-2.jpg",
      "img/productos/080-blu10-beige-con-marron-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu07",
    "nombre": "Blusa de satin · Vinotinto",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/081-blu07-vinotinto.jpg",
    "fotos": [
      "img/productos/081-blu07-vinotinto.jpg",
      "img/productos/081-blu07-vinotinto-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu07",
    "nombre": "Blusa de satin · Marrón",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 20.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/082-blu07-marron.jpg",
    "fotos": [
      "img/productos/082-blu07-marron.jpg",
      "img/productos/082-blu07-marron-2.jpg",
      "img/productos/082-blu07-marron-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Bo10",
    "nombre": "Body · Blanco satinado",
    "categoria": "Bodys",
    "subcategoria": "Manga corta",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/083-bo10-blanco-satinado.jpg",
    "fotos": [
      "img/productos/083-bo10-blanco-satinado.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo09",
    "nombre": "Body · Vinotinto satinado",
    "categoria": "Bodys",
    "subcategoria": "Manga corta",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/084-bo09-vinotinto-satinado.jpg",
    "fotos": [
      "img/productos/084-bo09-vinotinto-satinado.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo08",
    "nombre": "Body · Negro Satinado",
    "categoria": "Bodys",
    "subcategoria": "Manga corta",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/085-bo08-negro-satinado.jpg",
    "fotos": [
      "img/productos/085-bo08-negro-satinado.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo07",
    "nombre": "Bodys · Marrón sarinado",
    "categoria": "Bodys",
    "subcategoria": "Manga corta",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/086-bo07-marron-sarinado.jpg",
    "fotos": [
      "img/productos/086-bo07-marron-sarinado.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Bo06",
    "nombre": "Bodys · Rosado satinado",
    "categoria": "Bodys",
    "subcategoria": "Manga corta",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/087-bo06-rosado-satinado.jpg",
    "fotos": [
      "img/productos/087-bo06-rosado-satinado.jpg",
      "img/productos/087-bo06-rosado-satinado-2.jpg"
    ],
    "descripcion": "Doble tela licrada (Satinada)",
    "disponible": true
  },
  {
    "ref": "Blu06",
    "nombre": "Camisa de vestir · Azul con rayas blancas",
    "categoria": "Blusas",
    "subcategoria": "Manga larga de botones",
    "precio": 28.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/088-blu06-azul-con-rayas-blancas.jpg",
    "fotos": [
      "img/productos/088-blu06-azul-con-rayas-blancas.jpg",
      "img/productos/088-blu06-azul-con-rayas-blancas-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ch03",
    "nombre": "Sobretodo · Marrón claro",
    "categoria": "Chaquetas y sobretodo",
    "subcategoria": "",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/089-ch03-marron-claro.jpg",
    "fotos": [
      "img/productos/089-ch03-marron-claro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ch02",
    "nombre": "Sobretodo · Beige",
    "categoria": "Chaquetas y sobretodo",
    "subcategoria": "",
    "precio": 28.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/090-ch02-beige.jpg",
    "fotos": [
      "img/productos/090-ch02-beige.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "P04",
    "nombre": "Pullover · Beige",
    "categoria": "Pullover",
    "subcategoria": "",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/091-p04-beige.jpg",
    "fotos": [
      "img/productos/091-p04-beige.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ves05",
    "nombre": "Vestido con botones · Blanco con negro",
    "categoria": "Vestidos",
    "subcategoria": "",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/092-ves05-blanco-con-negro.jpg",
    "fotos": [
      "img/productos/092-ves05-blanco-con-negro.jpg",
      "img/productos/092-ves05-blanco-con-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "P03",
    "nombre": "Pullover · Azul",
    "categoria": "Pullover",
    "subcategoria": "",
    "precio": 14.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/093-p03-azul.jpg",
    "fotos": [
      "img/productos/093-p03-azul.jpg",
      "img/productos/093-p03-azul-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ac06",
    "nombre": "Lentes · Negro con dorado",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/094-ac06-negro-con-dorado.jpg",
    "fotos": [
      "img/productos/094-ac06-negro-con-dorado.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Cart6",
    "nombre": "Cartera · Marrón",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/095-cart6-marron.jpg",
    "fotos": [
      "img/productos/095-cart6-marron.jpg",
      "img/productos/095-cart6-marron-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Cart5",
    "nombre": "Cartera · Marrón",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 40.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/096-cart5-marron.jpg",
    "fotos": [
      "img/productos/096-cart5-marron.jpg",
      "img/productos/096-cart5-marron-2.jpg",
      "img/productos/096-cart5-marron-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Cart5",
    "nombre": "Cartera mini · Negro",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/097-cart5-negro.jpg",
    "fotos": [
      "img/productos/097-cart5-negro.jpg",
      "img/productos/097-cart5-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Cart4",
    "nombre": "Cartera · Vinotinto",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 32.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/098-cart4-vinotinto.jpg",
    "fotos": [
      "img/productos/098-cart4-vinotinto.jpg",
      "img/productos/098-cart4-vinotinto-2.jpg"
    ],
    "descripcion": "Sin el llavero",
    "disponible": true
  },
  {
    "ref": "Ac05",
    "nombre": "Lentes · Negro",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/099-ac05-negro.jpg",
    "fotos": [
      "img/productos/099-ac05-negro.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ac04",
    "nombre": "Lentes · Negro con dorado",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/100-ac04-negro-con-dorado.jpg",
    "fotos": [
      "img/productos/100-ac04-negro-con-dorado.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ac03",
    "nombre": "Lentes · Negro",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/101-ac03-negro.jpg",
    "fotos": [
      "img/productos/101-ac03-negro.jpg",
      "img/productos/101-ac03-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ac02",
    "nombre": "Lentes · Marrón con dorado",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/102-ac02-marron-con-dorado.jpg",
    "fotos": [
      "img/productos/102-ac02-marron-con-dorado.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ac01",
    "nombre": "Lentes · Animal print",
    "categoria": "Accesorios",
    "subcategoria": "Lentes",
    "precio": 15.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/103-ac01-animal-print.jpg",
    "fotos": [
      "img/productos/103-ac01-animal-print.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Bo05",
    "nombre": "Body straple · Negro",
    "categoria": "Bodys",
    "subcategoria": "Straple",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/104-bo05-negro.jpg",
    "fotos": [
      "img/productos/104-bo05-negro.jpg"
    ],
    "descripcion": "Tela licrada y totalmente forrado",
    "disponible": true
  },
  {
    "ref": "Bo04",
    "nombre": "Body straple · Blanco",
    "categoria": "Bodys",
    "subcategoria": "Straple",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/105-bo04-blanco.jpg",
    "fotos": [
      "img/productos/105-bo04-blanco.jpg"
    ],
    "descripcion": "Tela licrada y totalmente forrado",
    "disponible": true
  },
  {
    "ref": "Bo03",
    "nombre": "Body straple · Marrón",
    "categoria": "Bodys",
    "subcategoria": "Straple",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/106-bo03-marron.jpg",
    "fotos": [
      "img/productos/106-bo03-marron.jpg"
    ],
    "descripcion": "Tela licrada y totalmente forrado",
    "disponible": true
  },
  {
    "ref": "Ber03",
    "nombre": "Bermuda con correa · Crema",
    "categoria": "Bermudas y Short",
    "subcategoria": "Con dos piezas (Correa y Bermuda)",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/107-ber03-crema.jpg",
    "fotos": [
      "img/productos/107-ber03-crema.jpg",
      "img/productos/107-ber03-crema-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ent01",
    "nombre": "Enterizo con correa · Crema o beige",
    "categoria": "Set de vestir",
    "subcategoria": "",
    "precio": 45.0,
    "descuento": 15,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/108-ent01-crema-o-beige.jpg",
    "fotos": [
      "img/productos/108-ent01-crema-o-beige.jpg",
      "img/productos/108-ent01-crema-o-beige-2.jpg"
    ],
    "descripcion": "Viene con la correa",
    "disponible": true
  },
  {
    "ref": "Bla06",
    "nombre": "Blazer blanco · Blanco",
    "categoria": "Blazers",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/109-bla06-blanco.jpg",
    "fotos": [
      "img/productos/109-bla06-blanco.jpg",
      "img/productos/109-bla06-blanco-2.jpg"
    ],
    "descripcion": "Totalmente forrado por dentro y con hombreras para darle estructura en los hombros.",
    "disponible": true
  },
  {
    "ref": "Bla05",
    "nombre": "Blazer amarillo · Amarillo pastel",
    "categoria": "Blazers",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/110-bla05-amarillo-pastel.jpg",
    "fotos": [
      "img/productos/110-bla05-amarillo-pastel.jpg",
      "img/productos/110-bla05-amarillo-pastel-2.jpg"
    ],
    "descripcion": "Sin forro por dentro",
    "disponible": true
  },
  {
    "ref": "Bla04",
    "nombre": "Blazer negro · Negra con textura",
    "categoria": "Blazer",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/111-bla04-negra-con-textura.jpg",
    "fotos": [
      "img/productos/111-bla04-negra-con-textura.jpg",
      "img/productos/111-bla04-negra-con-textura-2.jpg",
      "img/productos/111-bla04-negra-con-textura-3.jpg"
    ],
    "descripcion": "Totalmente forrado por dentro.",
    "disponible": true
  },
  {
    "ref": "Bla03",
    "nombre": "Blazer negro · Negro",
    "categoria": "Blazers",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/112-bla03-negro.jpg",
    "fotos": [
      "img/productos/112-bla03-negro.jpg",
      "img/productos/112-bla03-negro-2.jpg"
    ],
    "descripcion": "Totalmente forrado por dentro y con hombreras para darle estructura en los hombros.",
    "disponible": true
  },
  {
    "ref": "Bla02",
    "nombre": "Blazer marrón · Marrón",
    "categoria": "Blazers",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/113-bla02-marron.jpg",
    "fotos": [
      "img/productos/113-bla02-marron.jpg",
      "img/productos/113-bla02-marron-2.jpg"
    ],
    "descripcion": "Totalmente forrado por dentro y con hombreras para darle estructura en los hombros.",
    "disponible": true
  },
  {
    "ref": "Bla01",
    "nombre": "Blazer vinotinto · Vinotinto",
    "categoria": "Blazers",
    "subcategoria": "",
    "precio": 50.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/114-bla01-vinotinto.jpg",
    "fotos": [
      "img/productos/114-bla01-vinotinto.jpg",
      "img/productos/114-bla01-vinotinto-2.jpg"
    ],
    "descripcion": "Totalmente forrado por dentro y con hombreras para darle estructura en los hombros.",
    "disponible": true
  },
  {
    "ref": "Pan01",
    "nombre": "Pantalón de vestir · Rosado",
    "categoria": "Pantalones",
    "subcategoria": "Pantalones de vestir",
    "precio": 35.0,
    "descuento": 15,
    "tallas": [
      "S",
      "M",
      "L"
    ],
    "foto": "img/productos/115-pan01-rosado.jpg",
    "fotos": [
      "img/productos/115-pan01-rosado.jpg",
      "img/productos/115-pan01-rosado-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "P02",
    "nombre": "Pullover · Blanco",
    "categoria": "Pullover",
    "subcategoria": "",
    "precio": 28.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/116-p02-blanco.jpg",
    "fotos": [
      "img/productos/116-p02-blanco.jpg",
      "img/productos/116-p02-blanco-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu04",
    "nombre": "Camisa de vestir · De rayas rosadas y blanca",
    "categoria": "Blusas",
    "subcategoria": "Manga larga de botones",
    "precio": 24.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/117-blu04-de-rayas-rosadas-y-blanca.jpg",
    "fotos": [
      "img/productos/117-blu04-de-rayas-rosadas-y-blanca.jpg",
      "img/productos/117-blu04-de-rayas-rosadas-y-blanca-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "SetV1",
    "nombre": "Set de vestir · Verde oliva",
    "categoria": "Set de vestir",
    "subcategoria": "Dos piezas",
    "precio": 45.0,
    "descuento": 15,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/118-setv1-verde-oliva.jpg",
    "fotos": [
      "img/productos/118-setv1-verde-oliva.jpg",
      "img/productos/118-setv1-verde-oliva-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ves04",
    "nombre": "Vestido largo · Negro",
    "categoria": "Vestidos",
    "subcategoria": "Vestido largo",
    "precio": 40.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/119-ves04-negro.jpg",
    "fotos": [
      "img/productos/119-ves04-negro.jpg",
      "img/productos/119-ves04-negro-2.jpg",
      "img/productos/119-ves04-negro-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ves03",
    "nombre": "Vestido estampado · Estampado azul y blanco",
    "categoria": "Vestido",
    "subcategoria": "Manga larga",
    "precio": 40.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/120-ves03-estampado-azul-y-blanco.jpg",
    "fotos": [
      "img/productos/120-ves03-estampado-azul-y-blanco.jpg",
      "img/productos/120-ves03-estampado-azul-y-blanco-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ber02",
    "nombre": "Bermuda · Crema",
    "categoria": "Bermudas y Short",
    "subcategoria": "",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "S",
      "M"
    ],
    "foto": "img/productos/121-ber02-crema.jpg",
    "fotos": [
      "img/productos/121-ber02-crema.jpg",
      "img/productos/121-ber02-crema-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "P01",
    "nombre": "Pullover · Rosado",
    "categoria": "Pullover",
    "subcategoria": "De botones",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/122-p01-rosado.jpg",
    "fotos": [
      "img/productos/122-p01-rosado.jpg",
      "img/productos/122-p01-rosado-2.jpg"
    ],
    "descripcion": "Funciona para M",
    "disponible": true
  },
  {
    "ref": "F01",
    "nombre": "Falda · Vinotinto",
    "categoria": "Faldas",
    "subcategoria": "Falda de satin",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/123-f01-vinotinto.jpg",
    "fotos": [
      "img/productos/123-f01-vinotinto.jpg",
      "img/productos/123-f01-vinotinto-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Bo02",
    "nombre": "Body straple · Rojo",
    "categoria": "Bodys",
    "subcategoria": "Straple",
    "precio": 18.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/124-bo02-rojo.jpg",
    "fotos": [
      "img/productos/124-bo02-rojo.jpg",
      "img/productos/124-bo02-rojo-2.jpg"
    ],
    "descripcion": "Tela licrada y es totalmente forrado",
    "disponible": true
  },
  {
    "ref": "Shr02",
    "nombre": "Short · Negro",
    "categoria": "Bermudas y Shorts",
    "subcategoria": "",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "M"
    ],
    "foto": "img/productos/125-shr02-negro.jpg",
    "fotos": [
      "img/productos/125-shr02-negro.jpg",
      "img/productos/125-shr02-negro-2.jpg",
      "img/productos/125-shr02-negro-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Shr01",
    "nombre": "Short de vestir · Crema",
    "categoria": "Bermudas y Shorts",
    "subcategoria": "",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "S",
      "L"
    ],
    "foto": "img/productos/126-shr01-crema.jpg",
    "fotos": [
      "img/productos/126-shr01-crema.jpg",
      "img/productos/126-shr01-crema-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ber01",
    "nombre": "Bermuda · Marron",
    "categoria": "Bermudas y Shorts",
    "subcategoria": "Dos piezas (correa y bermuda)",
    "precio": 35.0,
    "descuento": 0,
    "tallas": [
      "S",
      "L"
    ],
    "foto": "img/productos/127-ber01-marron.jpg",
    "fotos": [
      "img/productos/127-ber01-marron.jpg",
      "img/productos/127-ber01-marron-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Set02",
    "nombre": "Set deportivo · Rosado",
    "categoria": "Set deportivo",
    "subcategoria": "Dos piezas",
    "precio": 40.0,
    "descuento": 15,
    "tallas": [
      "S",
      "L"
    ],
    "foto": "img/productos/128-set02-rosado.jpg",
    "fotos": [
      "img/productos/128-set02-rosado.jpg",
      "img/productos/128-set02-rosado-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Set01",
    "nombre": "Set deportivo · Beige",
    "categoria": "Set deportivo",
    "subcategoria": "Dos piezas",
    "precio": 40.0,
    "descuento": 15,
    "tallas": [
      "S",
      "L"
    ],
    "foto": "img/productos/129-set01-beige.jpg",
    "fotos": [
      "img/productos/129-set01-beige.jpg",
      "img/productos/129-set01-beige-2.jpg"
    ],
    "descripcion": "Tela fresca",
    "disponible": true
  },
  {
    "ref": "Blu02",
    "nombre": "Blusa · Blanco con negro",
    "categoria": "Blusas",
    "subcategoria": "Blusa con botones",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/130-blu02-blanco-con-negro.jpg",
    "fotos": [
      "img/productos/130-blu02-blanco-con-negro.jpg",
      "img/productos/130-blu02-blanco-con-negro-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Ves02",
    "nombre": "Vestido · Amarillo pastal",
    "categoria": "Vestidos",
    "subcategoria": "Sin mangas",
    "precio": 40.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/131-ves02-amarillo-pastal.jpg",
    "fotos": [
      "img/productos/131-ves02-amarillo-pastal.jpg",
      "img/productos/131-ves02-amarillo-pastal-2.jpg"
    ],
    "descripcion": "Es talla S puede servir a talla M",
    "disponible": true
  },
  {
    "ref": "Bo01",
    "nombre": "Body · Marrón",
    "categoria": "Bodys",
    "subcategoria": "Tela licrada",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "L"
    ],
    "foto": "img/productos/132-bo01-marron.jpg",
    "fotos": [
      "img/productos/132-bo01-marron.jpg",
      "img/productos/132-bo01-marron-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu03",
    "nombre": "Blusa · Marron",
    "categoria": "Blusas",
    "subcategoria": "",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "XS"
    ],
    "foto": "img/productos/133-blu03-marron.jpg",
    "fotos": [
      "img/productos/133-blu03-marron.jpg",
      "img/productos/133-blu03-marron-2.jpg",
      "img/productos/133-blu03-marron-3.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Blu01",
    "nombre": "Blusa · Vinotinto",
    "categoria": "Blusas",
    "subcategoria": "Blusa con botones",
    "precio": 30.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/134-blu01-vinotinto.jpg",
    "fotos": [
      "img/productos/134-blu01-vinotinto.jpg",
      "img/productos/134-blu01-vinotinto-2.jpg"
    ],
    "descripcion": "",
    "disponible": true
  },
  {
    "ref": "Cart3",
    "nombre": "Cartera universitaria · Vinotinto",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 150.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/135-cart3-vinotinto.jpg",
    "fotos": [
      "img/productos/135-cart3-vinotinto.jpg",
      "img/productos/135-cart3-vinotinto-2.jpg"
    ],
    "descripcion": "Es grande / totte bag",
    "disponible": true
  },
  {
    "ref": "Cart2",
    "nombre": "Cartera · Marrón",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 120.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/136-cart2-marron.jpg",
    "fotos": [
      "img/productos/136-cart2-marron.jpg",
      "img/productos/136-cart2-marron-2.jpg"
    ],
    "descripcion": "Cartera marrón con la horma dura",
    "disponible": true
  },
  {
    "ref": "Cart1",
    "nombre": "Cartera · Negro",
    "categoria": "Accesorios",
    "subcategoria": "Carteras",
    "precio": 120.0,
    "descuento": 0,
    "tallas": [
      "S"
    ],
    "foto": "img/productos/137-cart1-negro.jpg",
    "fotos": [
      "img/productos/137-cart1-negro.jpg",
      "img/productos/137-cart1-negro-2.jpg"
    ],
    "descripcion": "Semi cuero",
    "disponible": true
  }
];
